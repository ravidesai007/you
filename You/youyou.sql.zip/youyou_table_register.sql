
-- --------------------------------------------------------

--
-- Table structure for table register
--

CREATE TABLE register (
  serial int(11) NOT NULL,
  name char(30) NOT NULL,
  user varchar(30) NOT NULL,
  email varchar(30) NOT NULL,
  phone bigint(30) NOT NULL,
  pass varchar(30) NOT NULL,
  c_pass varchar(30) NOT NULL,
  gender char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table register
--

INSERT INTO register (serial, name, user, email, phone, pass, c_pass, gender) VALUES
(20, 'Ravi Desai', 'ravi007', 'ravid4473@gmail.com', 9325235592, '123', '123', 'm'),
(23, 'Ravi Desai', 'ravi008', 'ravid4473@gmail.com', 9325235593, 'ravi1069', 'ravi1069', 'm'),
(25, 'Ravi Desai', 'ravi009', 'ravid4473@gmail.com', 9325235594, 'ravi1069', 'ravi1069', 'm'),
(26, 'Ravi Desai', 'ravi001', 'ravid4473@gmail.com', 9325235595, 'sdasd', 'cadsc', 'm');
