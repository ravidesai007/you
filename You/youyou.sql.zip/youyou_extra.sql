
--
-- Indexes for dumped tables
--

--
-- Indexes for table login
--
ALTER TABLE login
  ADD PRIMARY KEY (serial),
  ADD KEY user (user_log);

--
-- Indexes for table register
--
ALTER TABLE register
  ADD PRIMARY KEY (serial),
  ADD UNIQUE KEY username (user),
  ADD UNIQUE KEY phone (phone);
ALTER TABLE register ADD FULLTEXT KEY name (name,user,email,pass,c_pass,gender);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table login
--
ALTER TABLE login
  MODIFY serial int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table register
--
ALTER TABLE register
  MODIFY serial int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table login
--
ALTER TABLE login
  ADD CONSTRAINT user FOREIGN KEY (user_log) REFERENCES register (user);
