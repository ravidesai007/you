
-- --------------------------------------------------------

--
-- Table structure for table login
--

CREATE TABLE login (
  serial int(11) NOT NULL,
  user_log varchar(30) NOT NULL,
  pass_log varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table login
--

INSERT INTO login (serial, user_log, pass_log) VALUES
(1, 'ravi007', 'ravi1069'),
(3, 'ravi007', 'ravi1069');
